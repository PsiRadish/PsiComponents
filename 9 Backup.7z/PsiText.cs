﻿/*
 * User: Radish
 * Date: 3/3/2011
 * Time: 3:17 PM
 * Created in SharpDevelop
 */
 /* Once again, I implement something that already exists in the CLR (see String.Join method)
using System;
using System.Text;

namespace PsiRadish.Text
{
    /// <summary>
    /// Static class containing methods for use with System.Text.StringBuilder
    /// </summary>
    static class PstringBuilder
    {
        /// <summary>
        /// Appends an arbitrary number of strings to a given StringBuilder.
        /// </summary>
        /// <param name="strbuilder">The StringBuilder to append to.</param>
        /// <param name="strings">Strings to append, as multiple arguments or in an array.</param>
        /// <returns>The StringBuilder appended to.</returns>
        public static StringBuilder Append(StringBuilder strbuilder, params string[] strings)
        {
            foreach (string str in strings)
                strbuilder.Append(str);
            
            return strbuilder;
        }
    }
}
*/