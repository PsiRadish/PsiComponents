﻿/*
 * User: Radish
 * Date: 10/26/2010
 * Time: 6:02 PM
 * Created in SharpDevelop
 */
using System;

namespace PsiRadish
{
    namespace Controls
    {
        /// <summary>
        /// Description of SplitContainer.
        /// </summary>
        public class RadSplitContainer /*extends*/: System.Windows.Forms.SplitContainer
        {
            
        }
        
        /*
        public class SplitsContainer : RadSplitContainer
        {
            public SplitsContainer() : this(2)
            {
            }
            
            public SplitsContainer(int numpanels) : base()
            {
                
            }
        }
        */
    }
}
